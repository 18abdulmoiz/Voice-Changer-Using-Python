import sys
from PyQt5 import QtWidgets, QtGui, QtCore
from pydub import AudioSegment
import tempfile
import os
import sounddevice as sd
import soundfile as sf
import threading

class VoiceChangerApp(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Voice Changer")
        self.setGeometry(100, 100, 400, 200)

        self.input_label = QtWidgets.QLabel("Input Voice:", self)
        self.record_button = QtWidgets.QPushButton("Record", self)
        self.stop_button = QtWidgets.QPushButton("Stop", self)
        self.play_input_button = QtWidgets.QPushButton("▶ Play Input", self)
        self.process_button = QtWidgets.QPushButton("Apply Modulations", self)
        self.play_output_button = QtWidgets.QPushButton("▶ Play Output", self)
        self.output_label = QtWidgets.QLabel("Output Voice File:", self)
        self.output_file_display = QtWidgets.QLabel("Output File Path", self)

        button_color = "#000000"
        button_style = f"background-color: {button_color}; color: white; font-size: 18px;"

        self.record_button.setStyleSheet(button_style)
        self.stop_button.setStyleSheet(button_style)
        self.play_input_button.setStyleSheet(button_style)
        self.process_button.setStyleSheet(button_style)
        self.play_output_button.setStyleSheet(button_style)

        button_width = 200
        button_height = 30
        self.record_button.setFixedSize(button_width, button_height)
        self.stop_button.setFixedSize(button_width, button_height)
        self.play_input_button.setFixedSize(button_width, button_height)
        self.process_button.setFixedSize(button_width, button_height)
        self.play_output_button.setFixedSize(button_width, button_height)

        layout = QtWidgets.QVBoxLayout(self)
        top_layout = QtWidgets.QHBoxLayout()
        middle_layout = QtWidgets.QHBoxLayout()
        bottom_layout = QtWidgets.QHBoxLayout()

        top_layout.addWidget(self.input_label)
        top_layout.addWidget(self.record_button)
        top_layout.addWidget(self.stop_button)
        top_layout.addWidget(self.play_input_button)

        middle_layout.addWidget(self.process_button)

        bottom_layout.addWidget(self.play_output_button)
        bottom_layout.addWidget(self.output_label)
        bottom_layout.addWidget(self.output_file_display)

        layout.addLayout(top_layout)
        layout.addLayout(middle_layout)
        layout.addLayout(bottom_layout)

        self.shrill_radio_button = QtWidgets.QRadioButton("Shrill Voice", self)
        self.grave_radio_button = QtWidgets.QRadioButton("Grave Voice", self)

        voice_selection_layout = QtWidgets.QVBoxLayout()
        voice_selection_layout.addWidget(self.shrill_radio_button)
        voice_selection_layout.addWidget(self.grave_radio_button)
        voice_selection_layout.addStretch(1)

        layout.addLayout(voice_selection_layout)

        self.voice_selection_group = QtWidgets.QButtonGroup(self)
        self.voice_selection_group.addButton(self.shrill_radio_button)
        self.voice_selection_group.addButton(self.grave_radio_button)
        self.shrill_radio_button.setChecked(True)

        self.shrill_radio_button.toggled.connect(self.process_modulations)
        self.grave_radio_button.toggled.connect(self.process_modulations)

        self.setLayout(layout)

        self.record_button.clicked.connect(self.record_voice)
        self.stop_button.clicked.connect(self.stop_recording)
        self.play_input_button.clicked.connect(self.play_input_voice)
        self.process_button.clicked.connect(self.process_modulations)
        self.play_output_button.clicked.connect(self.play_output_voice)

        self.input_audio = None
        self.output_file_path = None
        self.recording_stream = None
        self.recording_thread = None

        self.modulation_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.modulation_slider.setMinimum(50)
        self.modulation_slider.setMaximum(200)
        self.modulation_slider.setValue(100)
        self.modulation_slider.setTickInterval(10)
        self.modulation_slider.setTickPosition(QtWidgets.QSlider.TicksBelow)

        self.pitch_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.pitch_slider.setMinimum(50)
        self.pitch_slider.setMaximum(200)
        self.pitch_slider.setValue(100)
        self.pitch_slider.setTickInterval(10)
        self.pitch_slider.setTickPosition(QtWidgets.QSlider.TicksBelow)

        self.modulation_slider.valueChanged.connect(self.update_modulation_factor)
        self.pitch_slider.valueChanged.connect(self.update_pitch_factor)

        layout.addWidget(self.modulation_slider)
        layout.addWidget(self.pitch_slider)

        self.modulation_factor = 1.0  # Default modulation factor
        self.pitch_factor = 1.0  # Default pitch factor

    def update_modulation_factor(self, value):
        self.modulation_factor = value / 100  # Normalize the value between 0.5 and 2.0

    def update_pitch_factor(self, value):
        self.pitch_factor = value / 100  # Normalize the value between 0.5 and 2.0

    def record_voice(self):
        self.recording_thread = threading.Thread(target=self._record_audio)
        self.recording_thread.start()

    def _record_audio(self):
        duration = 5
        sample_rate = 44100

        self.recording_stream = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=1)
        self.recording_timer = QtCore.QTimer()
        self.recording_timer.timeout.connect(self.stop_recording)
        self.recording_timer.start(duration * 1000)

    def stop_recording(self):
        if self.recording_stream is not None:
            self.recording_timer.stop()
            sd.stop()
            file_path = tempfile.mktemp(suffix='.wav')
            sf.write(file_path, self.recording_stream, 44100)
            self.input_audio = file_path

    def play_input_voice(self):
        if self.input_audio:
            try:
                sound = AudioSegment.from_file(self.input_audio)
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                    temp_file_path = temp_file.name
                    sound.export(temp_file_path, format='wav')
                    os.startfile(temp_file_path)
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Error", f"Error playing input voice: {e}")
        else:
            QtWidgets.QMessageBox.warning(self, "Warning", "Please record audio first.")

    def play_output_voice(self):
        if self.output_file_path:
            try:
                sound = AudioSegment.from_file(self.output_file_path)
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                    temp_file_path = temp_file.name
                    sound.export(temp_file_path, format='wav')
                    os.startfile(temp_file_path)
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Error", f"Error playing output voice: {e}")
        else:
            QtWidgets.QMessageBox.warning(self, "Warning", "Please process voice first.")

    def process_modulations(self):
        if self.input_audio:
            try:
                sound = AudioSegment.from_file(self.input_audio)

                if self.shrill_radio_button.isChecked():
                    modulated_sound = sound._spawn(sound.raw_data, overrides={
                        "frame_rate": int(sound.frame_rate * self.modulation_factor)
                    }).set_frame_rate(sound.frame_rate)
                elif self.grave_radio_button.isChecked():
                    modulated_sound = sound._spawn(sound.raw_data, overrides={
                        "frame_rate": int(sound.frame_rate / self.modulation_factor)
                    }).set_frame_rate(sound.frame_rate)
                else:
                    modulated_sound = sound

                modulated_sound = modulated_sound._spawn(modulated_sound.raw_data, overrides={
                    "frame_rate": int(modulated_sound.frame_rate * self.pitch_factor)
                }).set_frame_rate(modulated_sound.frame_rate)

                self.output_file_path = "output_modulated.wav"
                modulated_sound.export(self.output_file_path, format="wav")
                self.output_file_display.setText(self.output_file_path)
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Error", f"Error processing modulations: {e}")
        else:
            QtWidgets.QMessageBox.warning(self, "Warning", "Please record audio first.")

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = VoiceChangerApp()
    window.show()
    sys.exit(app.exec_())
